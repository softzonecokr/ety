	<footer class="py-5 bg-dark">
		<div class="container footer">
			<div class="row">
				<div class="col-md-12 text-white text-center">
					<h2 class="en1">ETY.KR</h2><!-- image or text  -->
					<p class="ks2 f12">
					무료테마인 <a href="http://ety.kr" target="_blank" class="color-white">에티테마</a>는 상업적으로 이용하셔도 됩니다. 하지만 배포, 재배포는 안됩니다. <br />
					또한 해당 테마에 대해서 지적재산권을 주장 할 수 없음을 미리 알려드립니다. <br />
					별도 문의사항은 <span class="color-white">mail@mail.com</span> 으로 연락 주시기 바랍니다.
					</p>
					<p class="ks2 f12">
						<i class="far fa-building"></i> 사무실 : 경기도 아름다운 아파트 101동 1004호<br />
						<i class="fas fa-phone"></i> 연락처 : 010-0000-0000<br />
						<i class="far fa-envelope-open"></i> <a href="mailto:mail@mail.com" class="color-white">Email : mail@mail.com</a><br />
						<i class="fas fa-fax"></i> 팩스번호 : 02) 1234-1234<br />
					</p>

				</div>
			</div>
		</div><!--/container-->
    </footer>
	<div class="container-fluid bg-gray">
		<div class="col-md-12 text-white text-center en1">
				Copyright 2019-2021 &copy; <a href="http://ety.kr" target="_blank"><span class="color-white ks4">에티테마</span></a>
		</div>
	</div><!-- /container -->